# AI Agent 智能对话系统

基于React框架和TypeScript构建的现代化AI Agent应用，集成火山云LLM服务，提供智能对话体验。

## ✨ 特性

- 🚀 **现代化架构**: React 18 + TypeScript + Tailwind CSS
- 🤖 **智能对话**: 集成火山云LLM服务，支持流式响应
- 💬 **实时交互**: 打字机效果展示，流畅的用户体验
- 📱 **响应式设计**: 完美适配桌面端和移动端
- 💾 **数据持久化**: 本地存储聊天记录和设置
- 🎨 **科技感UI**: 现代化界面设计，支持暗色主题
- ⚡ **高性能**: 优化的组件架构和状态管理

## 🛠️ 技术栈

- **前端框架**: React 18 + TypeScript
- **样式系统**: Tailwind CSS
- **状态管理**: React Hooks + Context
- **AI模型**: 火山云LLM服务
- **HTTP客户端**: OpenAI SDK
- **构建工具**: Create React App
- **图标库**: Lucide React

## 📁 项目结构

```
src/
├── components/          # React组件
│   ├── ChatInterface.tsx    # 聊天主界面
│   ├── MessageBubble.tsx    # 消息气泡
│   ├── TypingEffect.tsx     # 打字机效果
│   ├── Sidebar.tsx         # 侧边栏
│   └── ChatInput.tsx       # 输入组件
├── api/                 # API接口
│   └── services/
│       └── chatService.ts  # 聊天服务
├── hooks/               # 自定义Hooks
│   └── useChat.ts        # 聊天状态管理
├── utils/               # 工具函数
│   ├── storageService.ts # 本地存储
│   └── cn.ts            # 样式工具
├── types/               # TypeScript类型定义
│   └── index.ts         # 类型定义
└── styles/              # 样式文件
    └── index.css        # 全局样式
```

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并配置您的API密钥：

```env
REACT_APP_VOLCANO_API_KEY=your_api_key_here
REACT_APP_API_BASE_URL=https://ark.cn-beijing.volces.com/api/v3
REACT_APP_MODEL_ID=doubao-seed-1-6-251015
```

### 3. 启动开发服务器

```bash
npm start
```

应用将在 http://localhost:3000 启动

### 4. 构建生产版本

```bash
npm run build
```

## 💡 使用说明

### 基本功能

1. **新建对话**: 点击侧边栏的"新建对话"按钮
2. **发送消息**: 在输入框中输入消息，按Enter发送
3. **查看历史**: 在侧边栏查看和管理历史对话
4. **删除对话**: 悬停在对话上，点击删除按钮

### 高级功能

- **流式响应**: AI回复会实时显示，模拟打字效果
- **本地存储**: 聊天记录自动保存到浏览器本地存储
- **响应式设计**: 支持移动端和桌面端
- **错误处理**: 完善的错误提示和重试机制

## 🎨 界面特色

- **科技感设计**: 深色主题配合蓝色科技光效
- **流畅动画**: 打字机效果、加载动画、过渡效果
- **现代化布局**: 侧边栏+主界面的经典聊天应用布局
- **响应式适配**: 移动端优化的交互体验

## 🔧 自定义配置

### 修改主题色彩

在 `tailwind.config.js` 中修改颜色配置：

```javascript
colors: {
  'tech-dark': '#0a0a0a',
  'tech-gray': '#1a1a1a',
  'tech-blue': '#00d4ff',
  'tech-purple': '#8b5cf6',
  'tech-green': '#00ff88',
  'tech-orange': '#ff6b35'
}
```

### 调整打字机效果

在 `TypingEffect.tsx` 中修改打字速度和光标样式：

```typescript
interface TypingEffectProps {
  speed?: number;        // 打字速度（毫秒）
  showCursor?: boolean;   // 是否显示光标
  cursorChar?: string;    // 光标字符
}
```

### 配置LLM参数

在 `chatService.ts` 中修改模型参数：

```typescript
this.config = {
  apiKey: process.env.REACT_APP_VOLCANO_API_KEY || 'your_api_key',
  baseURL: process.env.REACT_APP_API_BASE_URL || 'https://ark.cn-beijing.volces.com/api/v3',
  model: process.env.REACT_APP_MODEL_ID || 'doubao-seed-1-6-251015',
  temperature: 0.7,
  maxTokens: 2000
};
```

## 📱 响应式设计

应用采用移动优先的响应式设计：

- **桌面端**: 左侧边栏 + 右侧聊天界面
- **平板端**: 可折叠侧边栏 + 全屏聊天界面
- **移动端**: 抽屉式侧边栏 + 全屏聊天界面

## 🔒 安全考虑

- **API密钥**: 使用环境变量存储敏感信息
- **本地存储**: 数据仅存储在用户本地浏览器
- **CORS**: 配置跨域访问策略
- **输入验证**: 对用户输入进行基本的验证和过滤

## 🐛 常见问题

### Q: API连接失败怎么办？
A: 检查以下几点：
- 确认API密钥是否正确配置
- 检查网络连接是否正常
- 验证API端点地址是否正确

### Q: 如何修改默认模型？
A: 在 `.env` 文件中修改 `REACT_APP_MODEL_ID` 变量

### Q: 如何禁用打字机效果？
A: 在 `MessageBubble.tsx` 中将 `showTypingEffect` 设为 `false`

## 🤝 贡献指南

欢迎提交Issue和Pull Request来改进这个项目！

## 📄 许可证

MIT License

## 🔗 相关链接

- [React官方文档](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [火山云API文档](https://www.volcengine.com/docs)
- [OpenAI SDK](https://github.com/openai/openai-node)