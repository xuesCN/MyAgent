import React, { useState, useRef, useEffect } from 'react';
import { cn } from '../utils/cn';
import { Send, Loader2 } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading?: boolean;
  placeholder?: string;
  className?: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading = false,
  placeholder = '输入消息...',
  className
}) => {
  const [inputValue, setInputValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // 自动调整文本框高度
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputValue]);

  const handleSend = () => {
    const trimmedValue = inputValue.trim();
    if (trimmedValue && !isLoading) {
      onSendMessage(trimmedValue);
      setInputValue('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
  };

  return (
    <div className={cn(
      'flex items-end gap-3 p-4 border-t border-gray-800 bg-tech-dark',
      className
    )}>
      {/* 输入框 */}
      <div className="flex-1 relative">
        <textarea
          ref={textareaRef}
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={isLoading}
          className={cn(
            'w-full min-h-[40px] max-h-[120px] px-4 py-2',
            'bg-tech-gray border border-gray-700 rounded-lg',
            'text-white placeholder-gray-500 resize-none',
            'focus:outline-none focus:border-tech-blue focus:ring-1 focus:ring-tech-blue',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            'transition-colors duration-200'
          )}
          rows={1}
        />
      </div>

      {/* 发送按钮 */}
      <button
        onClick={handleSend}
        disabled={!inputValue.trim() || isLoading}
        className={cn(
          'flex items-center justify-center',
          'w-10 h-10 rounded-lg',
          'bg-tech-blue hover:bg-tech-blue/90',
          'disabled:bg-gray-700 disabled:cursor-not-allowed',
          'transition-all duration-200',
          'focus:outline-none focus:ring-2 focus:ring-tech-blue focus:ring-offset-2 focus:ring-offset-tech-dark'
        )}
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 text-white animate-spin" />
        ) : (
          <Send className="w-4 h-4 text-white" />
        )}
      </button>
    </div>
  );
};