import { useState, useEffect, useCallback } from 'react';
import { ChatState, Message, ChatSession, StreamResponse } from '../types';
import { chatService } from '../api/services/chatService';
import { storageService } from '../utils/storageService';

export const useChat = () => {
  const [chatState, setChatState] = useState<ChatState>({
    currentSession: null,
    sessions: [],
    isLoading: false,
    error: null
  });

  // 初始化时加载历史会话
  useEffect(() => {
    const loadSessions = async () => {
      try {
        const sessions = await storageService.getSessions();
        setChatState(prev => ({
          ...prev,
          sessions,
          currentSession: sessions.length > 0 ? sessions[0] : null
        }));
      } catch (error) {
        console.error('Failed to load sessions:', error);
      }
    };

    loadSessions();
  }, []);

  // 创建新会话
  const createSession = useCallback(async (title: string = '新对话') => {
    try {
      const newSession: ChatSession = {
        id: Date.now().toString(),
        title,
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date()
      };

      const updatedSessions = [newSession, ...chatState.sessions];
      
      setChatState(prev => ({
        ...prev,
        sessions: updatedSessions,
        currentSession: newSession
      }));

      await storageService.saveSessions(updatedSessions);
    } catch (error) {
      console.error('Failed to create session:', error);
    }
  }, [chatState.sessions]);

  // 切换会话
  const switchSession = useCallback((sessionId: string) => {
    const session = chatState.sessions.find(s => s.id === sessionId);
    if (session) {
      setChatState(prev => ({
        ...prev,
        currentSession: session
      }));
    }
  }, [chatState.sessions]);

  // 删除会话
  const deleteSession = useCallback(async (sessionId: string) => {
    try {
      const updatedSessions = chatState.sessions.filter(s => s.id !== sessionId);
      
      setChatState(prev => ({
        ...prev,
        sessions: updatedSessions,
        currentSession: prev.currentSession?.id === sessionId 
          ? (updatedSessions.length > 0 ? updatedSessions[0] : null)
          : prev.currentSession
      }));

      await storageService.saveSessions(updatedSessions);
    } catch (error) {
      console.error('Failed to delete session:', error);
    }
  }, [chatState.sessions]);

  // 发送消息
  const sendMessage = useCallback(async (content: string) => {
    if (!chatState.currentSession || !content.trim()) return;

    setChatState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // 创建用户消息
      const userMessage: Message = {
        id: Date.now().toString(),
        content: content.trim(),
        sender: 'user',
        timestamp: new Date()
      };

      // 更新会话
      const updatedSession = {
        ...chatState.currentSession,
        messages: [...chatState.currentSession.messages, userMessage],
        updatedAt: new Date()
      };

      setChatState(prev => ({
        ...prev,
        currentSession: updatedSession
      }));

      // 创建AI消息的占位符
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: '',
        sender: 'ai',
        timestamp: new Date(),
        isStreaming: true
      };

      const sessionWithAIMessage = {
        ...updatedSession,
        messages: [...updatedSession.messages, aiMessage]
      };

      setChatState(prev => ({
        ...prev,
        currentSession: sessionWithAIMessage
      }));

      // 调用AI服务
      let aiContent = '';
      const stream = await chatService.sendMessageStream(content);

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        aiContent += content;

        // 更新AI消息内容
        setChatState(prev => {
          if (!prev.currentSession) return prev;
          
          const updatedMessages = prev.currentSession.messages.map(msg =>
            msg.id === aiMessage.id
              ? { ...msg, content: aiContent }
              : msg
          );

          return {
            ...prev,
            currentSession: {
              ...prev.currentSession,
              messages: updatedMessages
            }
          };
        });
      }

      // 完成流式响应
      const finalSession = {
        ...sessionWithAIMessage,
        messages: sessionWithAIMessage.messages.map(msg =>
          msg.id === aiMessage.id
            ? { ...msg, content: aiContent, isStreaming: false }
            : msg
        )
      };

      // 更新会话列表
      const updatedSessions = chatState.sessions.map(session =>
        session.id === finalSession.id ? finalSession : session
      );

      setChatState(prev => ({
        ...prev,
        currentSession: finalSession,
        sessions: updatedSessions,
        isLoading: false
      }));

      // 保存到本地存储
      await storageService.saveSessions(updatedSessions);

    } catch (error) {
      console.error('Failed to send message:', error);
      setChatState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : '发送消息失败',
        isLoading: false
      }));

      // 移除失败的AI消息
      if (chatState.currentSession) {
        const updatedSession = {
          ...chatState.currentSession,
          messages: chatState.currentSession.messages.filter(
            msg => msg.sender === 'user' || msg.content !== ''
          )
        };

        setChatState(prev => ({
          ...prev,
          currentSession: updatedSession
        }));
      }
    }
  }, [chatState.currentSession, chatState.sessions]);

  return {
    chatState,
    createSession,
    switchSession,
    deleteSession,
    sendMessage
  };
};